package com.aris.yemekgetir.ui.auth.LoginActivities.fragments.sebet;

import androidx.lifecycle.ViewModel;

public class SebetViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
