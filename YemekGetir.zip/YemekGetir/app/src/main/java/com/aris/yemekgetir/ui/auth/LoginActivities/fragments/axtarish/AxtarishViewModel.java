package com.aris.yemekgetir.ui.auth.LoginActivities.fragments.axtarish;

import androidx.lifecycle.ViewModel;

public class AxtarishViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
